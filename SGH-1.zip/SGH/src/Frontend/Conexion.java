package Frontend;

import java.net.Socket;

public class Conexion{

    public Conexion(){

    }

}
