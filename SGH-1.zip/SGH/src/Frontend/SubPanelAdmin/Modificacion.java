package Frontend.SubPanelAdmin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Modificacion extends JPanel implements ActionListener{

    public Modificacion(int sizex,int sizey, PanelAdmin admin){

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

}
