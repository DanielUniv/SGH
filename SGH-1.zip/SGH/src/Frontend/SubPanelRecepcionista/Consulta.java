package Frontend.SubPanelRecepcionista;

import javax.swing.*;

public class Consulta extends JPanel {
}
