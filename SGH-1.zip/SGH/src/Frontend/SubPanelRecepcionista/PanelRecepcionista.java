package Frontend.SubPanelRecepcionista;

import javax.swing.*;

public class PanelRecepcionista extends JPanel {

    public PanelRecepcionista(int sizex,int sizey,boolean real){

    }
}
