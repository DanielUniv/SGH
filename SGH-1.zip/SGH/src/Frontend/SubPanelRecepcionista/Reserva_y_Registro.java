package Frontend.SubPanelRecepcionista;

import javax.swing.*;

public class Reserva_y_Registro extends JPanel {
}
