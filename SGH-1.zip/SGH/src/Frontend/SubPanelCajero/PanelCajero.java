package Frontend.SubPanelCajero;

import javax.swing.*;

public class PanelCajero extends JPanel {

    public PanelCajero(int sizex,int sizey,boolean real){

    }
}
